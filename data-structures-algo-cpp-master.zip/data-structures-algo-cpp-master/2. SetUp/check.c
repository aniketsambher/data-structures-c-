#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Just checking \n");
    scanf("%d", &n);
    printf("Number is %d", n);
    return 0;
}
